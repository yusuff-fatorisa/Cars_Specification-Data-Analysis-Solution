# Hello, and welcome to another tutorial on using "pandas" and Python related libraries for Data Analytics 

##  The dataset used for this tutorial and the whole set of instructions / questions that reflects in this notebook is based on that provided by an online website.

## The website link is stated below

https://pythontraining.dzone.co.in/python-sample-papers/python-pandas-exercise.html

## On this page, you'll find the link to download the dataset as well as their provided instructions and solution as regards this question. Feel free to explore it more

###  The first step is to import the necessary python modules required for data Analysis tasks.


```python
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
```

### Next, load in the dataset and read a part of it for inspection and quick overview of the data in question. 


```python
cars_data_df = pd.read_csv("Cars_Data.csv", index_col = 0)
cars_data_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>body-style</th>
      <th>wheel-base</th>
      <th>length</th>
      <th>engine-type</th>
      <th>num-of-cylinders</th>
      <th>horsepower</th>
      <th>mileage</th>
      <th>price</th>
    </tr>
    <tr>
      <th>index</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>alfa-romero</td>
      <td>convertible</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>dohc</td>
      <td>four</td>
      <td>111</td>
      <td>21</td>
      <td>13495.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>alfa-romero</td>
      <td>convertible</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>dohc</td>
      <td>four</td>
      <td>111</td>
      <td>21</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>alfa-romero</td>
      <td>hatchback</td>
      <td>94.5</td>
      <td>171.2</td>
      <td>ohcv</td>
      <td>six</td>
      <td>154</td>
      <td>19</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>audi</td>
      <td>sedan</td>
      <td>99.8</td>
      <td>176.6</td>
      <td>ohc</td>
      <td>four</td>
      <td>102</td>
      <td>24</td>
      <td>13950.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>audi</td>
      <td>sedan</td>
      <td>99.4</td>
      <td>176.6</td>
      <td>ohc</td>
      <td>five</td>
      <td>115</td>
      <td>18</td>
      <td>17450.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>81</th>
      <td>volkswagen</td>
      <td>sedan</td>
      <td>97.3</td>
      <td>171.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>85</td>
      <td>27</td>
      <td>7975.0</td>
    </tr>
    <tr>
      <th>82</th>
      <td>volkswagen</td>
      <td>sedan</td>
      <td>97.3</td>
      <td>171.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>52</td>
      <td>37</td>
      <td>7995.0</td>
    </tr>
    <tr>
      <th>86</th>
      <td>volkswagen</td>
      <td>sedan</td>
      <td>97.3</td>
      <td>171.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>100</td>
      <td>26</td>
      <td>9995.0</td>
    </tr>
    <tr>
      <th>87</th>
      <td>volvo</td>
      <td>sedan</td>
      <td>104.3</td>
      <td>188.8</td>
      <td>ohc</td>
      <td>four</td>
      <td>114</td>
      <td>23</td>
      <td>12940.0</td>
    </tr>
    <tr>
      <th>88</th>
      <td>volvo</td>
      <td>wagon</td>
      <td>104.3</td>
      <td>188.8</td>
      <td>ohc</td>
      <td>four</td>
      <td>114</td>
      <td>23</td>
      <td>13415.0</td>
    </tr>
  </tbody>
</table>
<p>61 rows × 9 columns</p>
</div>



###  Next, check the necessary attributes and related information about the data to have a better understanding of the data.


```python
cars_data_df.shape
```




    (61, 9)




```python
cars_data_df.size
```




    549




```python
cars_data_df.dtypes
```




    brand                object
    body-style           object
    wheel-base          float64
    length              float64
    engine-type          object
    num-of-cylinders     object
    horsepower            int64
    mileage               int64
    price               float64
    dtype: object




```python
cars_data_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 61 entries, 0 to 88
    Data columns (total 9 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   brand             61 non-null     object 
     1   body-style        61 non-null     object 
     2   wheel-base        61 non-null     float64
     3   length            61 non-null     float64
     4   engine-type       61 non-null     object 
     5   num-of-cylinders  61 non-null     object 
     6   horsepower        61 non-null     int64  
     7   mileage           61 non-null     int64  
     8   price             58 non-null     float64
    dtypes: float64(3), int64(2), object(4)
    memory usage: 4.8+ KB



```python
cars_data_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>wheel-base</th>
      <th>length</th>
      <th>horsepower</th>
      <th>mileage</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>61.000000</td>
      <td>61.000000</td>
      <td>61.000000</td>
      <td>61.000000</td>
      <td>58.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>98.481967</td>
      <td>173.098361</td>
      <td>107.852459</td>
      <td>25.803279</td>
      <td>15387.000000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>6.679234</td>
      <td>14.021846</td>
      <td>53.524398</td>
      <td>8.129821</td>
      <td>11320.259841</td>
    </tr>
    <tr>
      <th>min</th>
      <td>88.400000</td>
      <td>141.100000</td>
      <td>48.000000</td>
      <td>13.000000</td>
      <td>5151.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>94.500000</td>
      <td>159.100000</td>
      <td>68.000000</td>
      <td>19.000000</td>
      <td>6808.500000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>96.300000</td>
      <td>171.200000</td>
      <td>100.000000</td>
      <td>25.000000</td>
      <td>11095.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>101.200000</td>
      <td>177.300000</td>
      <td>123.000000</td>
      <td>31.000000</td>
      <td>18120.500000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>120.900000</td>
      <td>208.100000</td>
      <td>288.000000</td>
      <td>47.000000</td>
      <td>45400.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# This is just an improved version of describe by making use of the available parameters 
cars_data_df.describe(include = "all")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>body-style</th>
      <th>wheel-base</th>
      <th>length</th>
      <th>engine-type</th>
      <th>num-of-cylinders</th>
      <th>horsepower</th>
      <th>mileage</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>61</td>
      <td>61</td>
      <td>61.000000</td>
      <td>61.000000</td>
      <td>61</td>
      <td>61</td>
      <td>61.000000</td>
      <td>61.000000</td>
      <td>58.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>16</td>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>toyota</td>
      <td>sedan</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>ohc</td>
      <td>four</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>7</td>
      <td>32</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>46</td>
      <td>39</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>98.481967</td>
      <td>173.098361</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>107.852459</td>
      <td>25.803279</td>
      <td>15387.000000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>6.679234</td>
      <td>14.021846</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>53.524398</td>
      <td>8.129821</td>
      <td>11320.259841</td>
    </tr>
    <tr>
      <th>min</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>88.400000</td>
      <td>141.100000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>48.000000</td>
      <td>13.000000</td>
      <td>5151.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>94.500000</td>
      <td>159.100000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>68.000000</td>
      <td>19.000000</td>
      <td>6808.500000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>96.300000</td>
      <td>171.200000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>100.000000</td>
      <td>25.000000</td>
      <td>11095.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>101.200000</td>
      <td>177.300000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>123.000000</td>
      <td>31.000000</td>
      <td>18120.500000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>120.900000</td>
      <td>208.100000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>288.000000</td>
      <td>47.000000</td>
      <td>45400.000000</td>
    </tr>
  </tbody>
</table>
</div>



####  Here, the code checks to confirm if there's any duplicated value in the dataset and the result reveals that there's 1 duplicate value.


```python
cars_data_df.duplicated().sum()
```




    1



####  Let's call out the value and inspect it. One approach i employ is to access the value directly above and below the duplicate value and inspect them together. Most often than not, the value will be directly above or below the duplicate value.

#### First, define a function that takes an integer and return a list of that number with +- difference.
#### Then, access the index of the duplicated value.
#### Due to the format by which the index value is displayed, as a list, to access the numerical value requires indexing as well.
#### So, access the value and pass it to the defined function. Then, pass the output to the "df.loc[ ] and visualize the output and confirm the duplicated values.
#### Note that this might not be a really necessary step, especially when dealing with large dataset with a large number of duplicated values. But sometimes, when doing data analysis, "SEEING IS BELIEVING". The fact that you can inspect an output and confirm its veracity gives you assurance with your skills and improves your overall results.


```python
def increment(number) :
    return [number - 1, number, number + 1]
```


```python
idx = cars_data_df[cars_data_df.duplicated()].index
new_idx = increment(idx[0])
dup_check = cars_data_df.loc[new_idx]
dup_check
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>body-style</th>
      <th>wheel-base</th>
      <th>length</th>
      <th>engine-type</th>
      <th>num-of-cylinders</th>
      <th>horsepower</th>
      <th>mileage</th>
      <th>price</th>
    </tr>
    <tr>
      <th>index</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>31</th>
      <td>isuzu</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>155.9</td>
      <td>ohc</td>
      <td>four</td>
      <td>70</td>
      <td>38</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>32</th>
      <td>isuzu</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>155.9</td>
      <td>ohc</td>
      <td>four</td>
      <td>70</td>
      <td>38</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>33</th>
      <td>jaguar</td>
      <td>sedan</td>
      <td>113.0</td>
      <td>199.6</td>
      <td>dohc</td>
      <td>six</td>
      <td>176</td>
      <td>15</td>
      <td>32250.0</td>
    </tr>
  </tbody>
</table>
</div>



#### Now, it's confirmed, the row below is the duplicate value.
#### You can take care of the duplicate value by dropping it with the set of function below.
#### Then, check to confirm if there's any more duplicated values.


```python
cars_data_df = cars_data_df.drop_duplicates()
cars_data_df.duplicated().sum()
```




    0



#### Check if there's missing values in the dataset.
#### The results revealed that there's missing values.
#### Not to worry, we'll tackle that in details in question 2.
#### But in most cases than not, you'll have to fix that before forging ahead with other activities.


```python
cars_data_df.isna().sum()
```




    brand               0
    body-style          0
    wheel-base          0
    length              0
    engine-type         0
    num-of-cylinders    0
    horsepower          0
    mileage             0
    price               2
    dtype: int64



# Python  Pandas Solution Using The Cars Dataset.

###  Question 1
### From the DataFrame, show the first and last 5 rows.

# SOLUTION
#### Use the head() and tail() methods of a DataFrame to get the first and last 5 rows of the Dataset.


```python
cars_data_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>body-style</th>
      <th>wheel-base</th>
      <th>length</th>
      <th>engine-type</th>
      <th>num-of-cylinders</th>
      <th>horsepower</th>
      <th>mileage</th>
      <th>price</th>
    </tr>
    <tr>
      <th>index</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>alfa-romero</td>
      <td>convertible</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>dohc</td>
      <td>four</td>
      <td>111</td>
      <td>21</td>
      <td>13495.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>alfa-romero</td>
      <td>convertible</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>dohc</td>
      <td>four</td>
      <td>111</td>
      <td>21</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>alfa-romero</td>
      <td>hatchback</td>
      <td>94.5</td>
      <td>171.2</td>
      <td>ohcv</td>
      <td>six</td>
      <td>154</td>
      <td>19</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>audi</td>
      <td>sedan</td>
      <td>99.8</td>
      <td>176.6</td>
      <td>ohc</td>
      <td>four</td>
      <td>102</td>
      <td>24</td>
      <td>13950.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>audi</td>
      <td>sedan</td>
      <td>99.4</td>
      <td>176.6</td>
      <td>ohc</td>
      <td>five</td>
      <td>115</td>
      <td>18</td>
      <td>17450.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
cars_data_df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>body-style</th>
      <th>wheel-base</th>
      <th>length</th>
      <th>engine-type</th>
      <th>num-of-cylinders</th>
      <th>horsepower</th>
      <th>mileage</th>
      <th>price</th>
    </tr>
    <tr>
      <th>index</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>81</th>
      <td>volkswagen</td>
      <td>sedan</td>
      <td>97.3</td>
      <td>171.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>85</td>
      <td>27</td>
      <td>7975.0</td>
    </tr>
    <tr>
      <th>82</th>
      <td>volkswagen</td>
      <td>sedan</td>
      <td>97.3</td>
      <td>171.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>52</td>
      <td>37</td>
      <td>7995.0</td>
    </tr>
    <tr>
      <th>86</th>
      <td>volkswagen</td>
      <td>sedan</td>
      <td>97.3</td>
      <td>171.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>100</td>
      <td>26</td>
      <td>9995.0</td>
    </tr>
    <tr>
      <th>87</th>
      <td>volvo</td>
      <td>sedan</td>
      <td>104.3</td>
      <td>188.8</td>
      <td>ohc</td>
      <td>four</td>
      <td>114</td>
      <td>23</td>
      <td>12940.0</td>
    </tr>
    <tr>
      <th>88</th>
      <td>volvo</td>
      <td>wagon</td>
      <td>104.3</td>
      <td>188.8</td>
      <td>ohc</td>
      <td>four</td>
      <td>114</td>
      <td>23</td>
      <td>13415.0</td>
    </tr>
  </tbody>
</table>
</div>



###  Question 2
### Clean csv and update the file.

# SOLUTION
#### To do this, i have a python file which contains a function that calculate and returns a DataFrame of :
#### 1. Counts of missing values
#### 2. Percentage of the counts of missing values
#### 3. Counts of non-missing values
#### 4. Percentage of the counts of non-missing values

#### To access this file, i have to change a working directory to that which contains the file.
#### And the steps to achieve that is what follows below
#### I access the file and run it, then i applied it on the dataset to get information about missing values


```python
%cd
%cd Desktop
%cd TDI (WQU)
%cd Random Files
%cd DSN Hackathon
%cd KPMG
%cd Task 1
os.listdir(".")
```

    C:\Users\adeoye oluwatobi
    C:\Users\adeoye oluwatobi\Desktop
    C:\Users\adeoye oluwatobi\Desktop\TDI (WQU)
    C:\Users\adeoye oluwatobi\Desktop\TDI (WQU)\Random Files
    C:\Users\adeoye oluwatobi\Desktop\TDI (WQU)\Random Files\DSN Hackathon
    C:\Users\adeoye oluwatobi\Desktop\TDI (WQU)\Random Files\DSN Hackathon\KPMG
    C:\Users\adeoye oluwatobi\Desktop\TDI (WQU)\Random Files\DSN Hackathon\KPMG\Task 1





    ['.ipynb_checkpoints',
     'convert_dtype.py',
     'create_columns.py',
     'customer_tenure kde plot.png',
     'describe_na.py',
     'Forage Task1.ipynb',
     'histogram plot of list price.png',
     'job_industry kde plot.png',
     'job_title kde plot.png',
     'kde plot.png',
     'KPMG_VI_New_raw_data_update_final.xlsx',
     'profits kde plot.png',
     'property_valuation kde plot.png',
     'wealth_segment kde plot.png',
     '__pycache__']




```python
# %load describe_na.py
def describe_na(df) :
    na_sum = dict(df.isnull().sum())
    not_na_sum = dict(df.notnull().sum())
    total = len(df)
    na_expand = [ na for na in na_sum.values() if na > 0 ]
    na_list = [ (na_s / total) * 100 for na_s in na_sum.values() if na_s > 0 ]
    not_na_expand = [ not_na for not_na in not_na_sum.values() if not_na < total ]
    not_na_list = [ (not_na_s / total) * 100 for not_na_s in not_na_sum.values() if not_na_s < total ]
    na_notna_df = pd.DataFrame( { 'null_counts' : na_expand, 'null_percent(%)' : na_list, 'not_null_counts' : not_na_expand, 
                               'not_null_percent(%)' : not_na_list}, index = [indices for indices, value in na_sum.items() if value > 0] )
    na_notna_df.index.name = 'column_name'
    return na_notna_df


    """This function compiles the missing values of a given DataFrame ."""
    """And displays the output in a nicely formatted DataFrame."""
    """First, it calculates the Series output of the sum of missing values in each column of the given DataFrame.""" 
    """Then it converts the column_name and the corresponding sum of missing values into a key : value pair of a dictionary"""
    """Secondly, it calculates the Series output of the sum of non-missing values in each column of the given DataFrame.""" 
    """Then it converts the column_name and the corresponding sum of non-missing values into a key : value pair of a dictionary"""
    """Next, it calculates the total length of the given DataFrame"""
    """Next, it gets the missing values from the missing values dictionary if the value is greater than Zero"""
    """And it calculates what percentage of the total column is the missing value"""
    """Next, it gets the non-missing values from the non-missing values dictionary if the value is greater than length of the column"""
    """And it calculates what percentage of the total column is the non-missing value"""
    """Finally, it creates a new DataFrame from all the data collated above"""
    """And it gives the index_column a name"""
```

#### Remember, from checking the missing values earlier, the "price" column is that which has missing values.
#### So, access the column and inspect it before applying the function on the Dataset.
#### Then inspect it after applying the function on the Dataset.


```python
cars_data_df["price"].describe()
```




    count       58.000000
    mean     15387.000000
    std      11320.259841
    min       5151.000000
    25%       6808.500000
    50%      11095.000000
    75%      18120.500000
    max      45400.000000
    Name: price, dtype: float64




```python
describe_na(cars_data_df)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>null_counts</th>
      <th>null_percent(%)</th>
      <th>not_null_counts</th>
      <th>not_null_percent(%)</th>
    </tr>
    <tr>
      <th>column_name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>price</th>
      <td>2</td>
      <td>3.333333</td>
      <td>58</td>
      <td>96.666667</td>
    </tr>
  </tbody>
</table>
</div>



#### After the function has been applied on the Dataset, inspect it again to confirm the missing value has been replaced.


```python
cars_data_df["price"].fillna(cars_data_df["price"].mean(), inplace = True)
```

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\series.py:4517: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      return super().fillna(



```python
describe_na(cars_data_df)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>null_counts</th>
      <th>null_percent(%)</th>
      <th>not_null_counts</th>
      <th>not_null_percent(%)</th>
    </tr>
    <tr>
      <th>column_name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
cars_data_df["price"].describe()
```




    count       60.000000
    mean     15387.000000
    std      11126.736866
    min       5151.000000
    25%       6835.500000
    50%      12392.500000
    75%      17673.500000
    max      45400.000000
    Name: price, dtype: float64



###  Question 3
### Find which car brand price is maximum

# SOLUTION


```python
max_info_df = cars_data_df[["brand", "price"]].sort_values(by = "price", ascending = False)
max_car_price = max_info_df.nlargest(1, "price")
max_car_price
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>price</th>
    </tr>
    <tr>
      <th>index</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>47</th>
      <td>mercedes-benz</td>
      <td>45400.0</td>
    </tr>
  </tbody>
</table>
</div>



### Question 4
### Find all "Nissan" Cars informations.

# SOLUTION


```python
nissan_cars_info = cars_data_df[cars_data_df["brand"] == "nissan"]
nissan_cars_info
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>body-style</th>
      <th>wheel-base</th>
      <th>length</th>
      <th>engine-type</th>
      <th>num-of-cylinders</th>
      <th>horsepower</th>
      <th>mileage</th>
      <th>price</th>
    </tr>
    <tr>
      <th>index</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>53</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>165.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>55</td>
      <td>45</td>
      <td>7099.0</td>
    </tr>
    <tr>
      <th>54</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>165.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>69</td>
      <td>31</td>
      <td>6649.0</td>
    </tr>
    <tr>
      <th>55</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>165.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>69</td>
      <td>31</td>
      <td>6849.0</td>
    </tr>
    <tr>
      <th>56</th>
      <td>nissan</td>
      <td>wagon</td>
      <td>94.5</td>
      <td>170.2</td>
      <td>ohc</td>
      <td>four</td>
      <td>69</td>
      <td>31</td>
      <td>7349.0</td>
    </tr>
    <tr>
      <th>57</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>100.4</td>
      <td>184.6</td>
      <td>ohcv</td>
      <td>six</td>
      <td>152</td>
      <td>19</td>
      <td>13499.0</td>
    </tr>
  </tbody>
</table>
</div>



###  Alternative method to answer question 4


```python
nissan_cars_info_alt = cars_data_df.query("brand == 'nissan'")
nissan_cars_info_alt
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>body-style</th>
      <th>wheel-base</th>
      <th>length</th>
      <th>engine-type</th>
      <th>num-of-cylinders</th>
      <th>horsepower</th>
      <th>mileage</th>
      <th>price</th>
    </tr>
    <tr>
      <th>index</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>53</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>165.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>55</td>
      <td>45</td>
      <td>7099.0</td>
    </tr>
    <tr>
      <th>54</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>165.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>69</td>
      <td>31</td>
      <td>6649.0</td>
    </tr>
    <tr>
      <th>55</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>165.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>69</td>
      <td>31</td>
      <td>6849.0</td>
    </tr>
    <tr>
      <th>56</th>
      <td>nissan</td>
      <td>wagon</td>
      <td>94.5</td>
      <td>170.2</td>
      <td>ohc</td>
      <td>four</td>
      <td>69</td>
      <td>31</td>
      <td>7349.0</td>
    </tr>
    <tr>
      <th>57</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>100.4</td>
      <td>184.6</td>
      <td>ohcv</td>
      <td>six</td>
      <td>152</td>
      <td>19</td>
      <td>13499.0</td>
    </tr>
  </tbody>
</table>
</div>



###  Question 5
### Let's calculate total number of cars per firm.

# SOLUTION


```python
cars_by_firm = cars_data_df["brand"].value_counts()
cars_by_firm
```




    toyota           7
    bmw              6
    nissan           5
    mazda            5
    mercedes-benz    4
    audi             4
    volkswagen       4
    mitsubishi       4
    jaguar           3
    chevrolet        3
    porsche          3
    honda            3
    alfa-romero      3
    dodge            2
    volvo            2
    isuzu            2
    Name: brand, dtype: int64



#### And as an addition to the results, plot a visualization for the returned output.


```python
cars_by_firm.plot(kind = "bar",  rot = 75, xlabel = "Car Firms / Brands", ylabel = "Frequency", title = "Car Groups by Firms")
```




    <AxesSubplot:title={'center':'Car Groups by Firms'}, xlabel='Car Firms / Brands', ylabel='Frequency'>




![png](output_53_1.png)


### Alternative method to answer question 5


```python
cars_by_firm_alt = cars_data_df.groupby("brand")["brand"].size().sort_values(ascending = False)
cars_by_firm_alt
```




    brand
    toyota           7
    bmw              6
    nissan           5
    mazda            5
    volkswagen       4
    mitsubishi       4
    mercedes-benz    4
    audi             4
    porsche          3
    jaguar           3
    honda            3
    chevrolet        3
    alfa-romero      3
    volvo            2
    isuzu            2
    dodge            2
    Name: brand, dtype: int64




```python
cars_by_firm_alt.plot(kind = "barh",  rot = 35, xlabel = "Car Firms / Brands", ylabel = "Frequency", title = "Car Groups by Firms")
```




    <AxesSubplot:title={'center':'Car Groups by Firms'}, ylabel='Car Firms / Brands'>




![png](output_56_1.png)


### Another alternative solution to Question 5 and its visualization


```python
cars_by_firm_alt1 = cars_data_df.groupby("brand")["brand"].count().sort_values(ascending = False)
cars_by_firm_alt1
```




    brand
    toyota           7
    bmw              6
    nissan           5
    mazda            5
    volkswagen       4
    mitsubishi       4
    mercedes-benz    4
    audi             4
    porsche          3
    jaguar           3
    honda            3
    chevrolet        3
    alfa-romero      3
    volvo            2
    isuzu            2
    dodge            2
    Name: brand, dtype: int64




```python
cars_by_firm_alt1.plot(kind = "bar",  rot = 75, xlabel = "Car Firms / Brands", ylabel = "Frequency", title = "Car Groups by Firms")
```




    <AxesSubplot:title={'center':'Car Groups by Firms'}, xlabel='Car Firms / Brands', ylabel='Frequency'>




![png](output_59_1.png)


### Question 6
### Find each brand's Highest priced car.

# SOLUTION


```python
brands_expensive = cars_data_df.groupby("brand")["price"].max()
brands_expensive
```




    brand
    alfa-romero      16500.0
    audi             18920.0
    bmw              41315.0
    chevrolet         6575.0
    dodge             6377.0
    honda            12945.0
    isuzu            15387.0
    jaguar           36000.0
    mazda            18344.0
    mercedes-benz    45400.0
    mitsubishi        8189.0
    nissan           13499.0
    porsche          37028.0
    toyota           15750.0
    volkswagen        9995.0
    volvo            13415.0
    Name: price, dtype: float64



#### You can create a DataFrame from the output to make the result nicely formatted.


```python
brands_expensive_df = pd.DataFrame({"brand" : brands_expensive.index, "max_price" : brands_expensive.values})
brands_expensive_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>max_price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>alfa-romero</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>audi</td>
      <td>18920.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bmw</td>
      <td>41315.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>chevrolet</td>
      <td>6575.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>dodge</td>
      <td>6377.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>honda</td>
      <td>12945.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>isuzu</td>
      <td>15387.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>jaguar</td>
      <td>36000.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>mazda</td>
      <td>18344.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>mercedes-benz</td>
      <td>45400.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>mitsubishi</td>
      <td>8189.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>nissan</td>
      <td>13499.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>porsche</td>
      <td>37028.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>toyota</td>
      <td>15750.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>volkswagen</td>
      <td>9995.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>volvo</td>
      <td>13415.0</td>
    </tr>
  </tbody>
</table>
</div>



### Question 7
### Find the average mileage of each car brand.

# SOLUTION


```python
brand_mileage_avg = cars_data_df.groupby("brand")["mileage"].mean()
brand_mileage_avg
```




    brand
    alfa-romero      20.333333
    audi             20.000000
    bmw              19.000000
    chevrolet        41.000000
    dodge            31.000000
    honda            26.333333
    isuzu            31.000000
    jaguar           14.333333
    mazda            28.000000
    mercedes-benz    18.000000
    mitsubishi       29.500000
    nissan           31.400000
    porsche          17.000000
    toyota           28.714286
    volkswagen       31.750000
    volvo            23.000000
    Name: mileage, dtype: float64



#### You can create a DataFrame from the output so the result can be nicely formatted.


```python
brand_mileage_avg_df = pd.DataFrame({"brand" : brand_mileage_avg.index, "mileage_avg" : brand_mileage_avg.values})
brand_mileage_avg_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>mileage_avg</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>alfa-romero</td>
      <td>20.333333</td>
    </tr>
    <tr>
      <th>1</th>
      <td>audi</td>
      <td>20.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bmw</td>
      <td>19.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>chevrolet</td>
      <td>41.000000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>dodge</td>
      <td>31.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>honda</td>
      <td>26.333333</td>
    </tr>
    <tr>
      <th>6</th>
      <td>isuzu</td>
      <td>31.000000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>jaguar</td>
      <td>14.333333</td>
    </tr>
    <tr>
      <th>8</th>
      <td>mazda</td>
      <td>28.000000</td>
    </tr>
    <tr>
      <th>9</th>
      <td>mercedes-benz</td>
      <td>18.000000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>mitsubishi</td>
      <td>29.500000</td>
    </tr>
    <tr>
      <th>11</th>
      <td>nissan</td>
      <td>31.400000</td>
    </tr>
    <tr>
      <th>12</th>
      <td>porsche</td>
      <td>17.000000</td>
    </tr>
    <tr>
      <th>13</th>
      <td>toyota</td>
      <td>28.714286</td>
    </tr>
    <tr>
      <th>14</th>
      <td>volkswagen</td>
      <td>31.750000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>volvo</td>
      <td>23.000000</td>
    </tr>
  </tbody>
</table>
</div>



### Question 8
### Sort all cars by Price.

# SOLUTION


```python
sorted_by_price = cars_data_df.sort_values(by = "price", ascending = False)
sorted_by_price
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>body-style</th>
      <th>wheel-base</th>
      <th>length</th>
      <th>engine-type</th>
      <th>num-of-cylinders</th>
      <th>horsepower</th>
      <th>mileage</th>
      <th>price</th>
    </tr>
    <tr>
      <th>index</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>47</th>
      <td>mercedes-benz</td>
      <td>hardtop</td>
      <td>112.0</td>
      <td>199.2</td>
      <td>ohcv</td>
      <td>eight</td>
      <td>184</td>
      <td>14</td>
      <td>45400.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>bmw</td>
      <td>sedan</td>
      <td>103.5</td>
      <td>193.8</td>
      <td>ohc</td>
      <td>six</td>
      <td>182</td>
      <td>16</td>
      <td>41315.0</td>
    </tr>
    <tr>
      <th>46</th>
      <td>mercedes-benz</td>
      <td>sedan</td>
      <td>120.9</td>
      <td>208.1</td>
      <td>ohcv</td>
      <td>eight</td>
      <td>184</td>
      <td>14</td>
      <td>40960.0</td>
    </tr>
    <tr>
      <th>62</th>
      <td>porsche</td>
      <td>convertible</td>
      <td>89.5</td>
      <td>168.9</td>
      <td>ohcf</td>
      <td>six</td>
      <td>207</td>
      <td>17</td>
      <td>37028.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>bmw</td>
      <td>sedan</td>
      <td>110.0</td>
      <td>197.0</td>
      <td>ohc</td>
      <td>six</td>
      <td>182</td>
      <td>15</td>
      <td>36880.0</td>
    </tr>
    <tr>
      <th>35</th>
      <td>jaguar</td>
      <td>sedan</td>
      <td>102.0</td>
      <td>191.7</td>
      <td>ohcv</td>
      <td>twelve</td>
      <td>262</td>
      <td>13</td>
      <td>36000.0</td>
    </tr>
    <tr>
      <th>34</th>
      <td>jaguar</td>
      <td>sedan</td>
      <td>113.0</td>
      <td>199.6</td>
      <td>dohc</td>
      <td>six</td>
      <td>176</td>
      <td>15</td>
      <td>35550.0</td>
    </tr>
    <tr>
      <th>61</th>
      <td>porsche</td>
      <td>hardtop</td>
      <td>89.5</td>
      <td>168.9</td>
      <td>ohcf</td>
      <td>six</td>
      <td>207</td>
      <td>17</td>
      <td>34028.0</td>
    </tr>
    <tr>
      <th>33</th>
      <td>jaguar</td>
      <td>sedan</td>
      <td>113.0</td>
      <td>199.6</td>
      <td>dohc</td>
      <td>six</td>
      <td>176</td>
      <td>15</td>
      <td>32250.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>bmw</td>
      <td>sedan</td>
      <td>103.5</td>
      <td>189.0</td>
      <td>ohc</td>
      <td>six</td>
      <td>182</td>
      <td>16</td>
      <td>30760.0</td>
    </tr>
    <tr>
      <th>45</th>
      <td>mercedes-benz</td>
      <td>wagon</td>
      <td>110.0</td>
      <td>190.9</td>
      <td>ohc</td>
      <td>five</td>
      <td>123</td>
      <td>22</td>
      <td>28248.0</td>
    </tr>
    <tr>
      <th>44</th>
      <td>mercedes-benz</td>
      <td>sedan</td>
      <td>110.0</td>
      <td>190.9</td>
      <td>ohc</td>
      <td>five</td>
      <td>123</td>
      <td>22</td>
      <td>25552.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>bmw</td>
      <td>sedan</td>
      <td>101.2</td>
      <td>176.8</td>
      <td>ohc</td>
      <td>six</td>
      <td>121</td>
      <td>21</td>
      <td>20970.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>audi</td>
      <td>wagon</td>
      <td>105.8</td>
      <td>192.7</td>
      <td>ohc</td>
      <td>five</td>
      <td>110</td>
      <td>19</td>
      <td>18920.0</td>
    </tr>
    <tr>
      <th>43</th>
      <td>mazda</td>
      <td>sedan</td>
      <td>104.9</td>
      <td>175.0</td>
      <td>ohc</td>
      <td>four</td>
      <td>72</td>
      <td>31</td>
      <td>18344.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>audi</td>
      <td>sedan</td>
      <td>99.4</td>
      <td>176.6</td>
      <td>ohc</td>
      <td>five</td>
      <td>115</td>
      <td>18</td>
      <td>17450.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>bmw</td>
      <td>sedan</td>
      <td>101.2</td>
      <td>176.8</td>
      <td>ohc</td>
      <td>four</td>
      <td>101</td>
      <td>23</td>
      <td>16925.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>alfa-romero</td>
      <td>convertible</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>dohc</td>
      <td>four</td>
      <td>111</td>
      <td>21</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>alfa-romero</td>
      <td>hatchback</td>
      <td>94.5</td>
      <td>171.2</td>
      <td>ohcv</td>
      <td>six</td>
      <td>154</td>
      <td>19</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>bmw</td>
      <td>sedan</td>
      <td>101.2</td>
      <td>176.8</td>
      <td>ohc</td>
      <td>four</td>
      <td>101</td>
      <td>23</td>
      <td>16430.0</td>
    </tr>
    <tr>
      <th>79</th>
      <td>toyota</td>
      <td>wagon</td>
      <td>104.5</td>
      <td>187.8</td>
      <td>dohc</td>
      <td>six</td>
      <td>156</td>
      <td>19</td>
      <td>15750.0</td>
    </tr>
    <tr>
      <th>63</th>
      <td>porsche</td>
      <td>hatchback</td>
      <td>98.4</td>
      <td>175.7</td>
      <td>dohcv</td>
      <td>eight</td>
      <td>288</td>
      <td>17</td>
      <td>15387.0</td>
    </tr>
    <tr>
      <th>31</th>
      <td>isuzu</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>155.9</td>
      <td>ohc</td>
      <td>four</td>
      <td>70</td>
      <td>38</td>
      <td>15387.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>audi</td>
      <td>sedan</td>
      <td>99.8</td>
      <td>177.3</td>
      <td>ohc</td>
      <td>five</td>
      <td>110</td>
      <td>19</td>
      <td>15250.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>audi</td>
      <td>sedan</td>
      <td>99.8</td>
      <td>176.6</td>
      <td>ohc</td>
      <td>four</td>
      <td>102</td>
      <td>24</td>
      <td>13950.0</td>
    </tr>
    <tr>
      <th>57</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>100.4</td>
      <td>184.6</td>
      <td>ohcv</td>
      <td>six</td>
      <td>152</td>
      <td>19</td>
      <td>13499.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>alfa-romero</td>
      <td>convertible</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>dohc</td>
      <td>four</td>
      <td>111</td>
      <td>21</td>
      <td>13495.0</td>
    </tr>
    <tr>
      <th>88</th>
      <td>volvo</td>
      <td>wagon</td>
      <td>104.3</td>
      <td>188.8</td>
      <td>ohc</td>
      <td>four</td>
      <td>114</td>
      <td>23</td>
      <td>13415.0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>honda</td>
      <td>sedan</td>
      <td>96.5</td>
      <td>175.4</td>
      <td>ohc</td>
      <td>four</td>
      <td>101</td>
      <td>24</td>
      <td>12945.0</td>
    </tr>
    <tr>
      <th>87</th>
      <td>volvo</td>
      <td>sedan</td>
      <td>104.3</td>
      <td>188.8</td>
      <td>ohc</td>
      <td>four</td>
      <td>114</td>
      <td>23</td>
      <td>12940.0</td>
    </tr>
    <tr>
      <th>39</th>
      <td>mazda</td>
      <td>hatchback</td>
      <td>95.3</td>
      <td>169.0</td>
      <td>rotor</td>
      <td>two</td>
      <td>101</td>
      <td>17</td>
      <td>11845.0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>honda</td>
      <td>sedan</td>
      <td>96.5</td>
      <td>169.1</td>
      <td>ohc</td>
      <td>four</td>
      <td>100</td>
      <td>25</td>
      <td>10345.0</td>
    </tr>
    <tr>
      <th>86</th>
      <td>volkswagen</td>
      <td>sedan</td>
      <td>97.3</td>
      <td>171.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>100</td>
      <td>26</td>
      <td>9995.0</td>
    </tr>
    <tr>
      <th>71</th>
      <td>toyota</td>
      <td>wagon</td>
      <td>95.7</td>
      <td>169.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>62</td>
      <td>27</td>
      <td>8778.0</td>
    </tr>
    <tr>
      <th>52</th>
      <td>mitsubishi</td>
      <td>sedan</td>
      <td>96.3</td>
      <td>172.4</td>
      <td>ohc</td>
      <td>four</td>
      <td>88</td>
      <td>25</td>
      <td>8189.0</td>
    </tr>
    <tr>
      <th>82</th>
      <td>volkswagen</td>
      <td>sedan</td>
      <td>97.3</td>
      <td>171.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>52</td>
      <td>37</td>
      <td>7995.0</td>
    </tr>
    <tr>
      <th>81</th>
      <td>volkswagen</td>
      <td>sedan</td>
      <td>97.3</td>
      <td>171.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>85</td>
      <td>27</td>
      <td>7975.0</td>
    </tr>
    <tr>
      <th>70</th>
      <td>toyota</td>
      <td>wagon</td>
      <td>95.7</td>
      <td>169.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>62</td>
      <td>27</td>
      <td>7898.0</td>
    </tr>
    <tr>
      <th>80</th>
      <td>volkswagen</td>
      <td>sedan</td>
      <td>97.3</td>
      <td>171.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>52</td>
      <td>37</td>
      <td>7775.0</td>
    </tr>
    <tr>
      <th>56</th>
      <td>nissan</td>
      <td>wagon</td>
      <td>94.5</td>
      <td>170.2</td>
      <td>ohc</td>
      <td>four</td>
      <td>69</td>
      <td>31</td>
      <td>7349.0</td>
    </tr>
    <tr>
      <th>27</th>
      <td>honda</td>
      <td>wagon</td>
      <td>96.5</td>
      <td>157.1</td>
      <td>ohc</td>
      <td>four</td>
      <td>76</td>
      <td>30</td>
      <td>7295.0</td>
    </tr>
    <tr>
      <th>53</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>165.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>55</td>
      <td>45</td>
      <td>7099.0</td>
    </tr>
    <tr>
      <th>51</th>
      <td>mitsubishi</td>
      <td>sedan</td>
      <td>96.3</td>
      <td>172.4</td>
      <td>ohc</td>
      <td>four</td>
      <td>88</td>
      <td>25</td>
      <td>6989.0</td>
    </tr>
    <tr>
      <th>69</th>
      <td>toyota</td>
      <td>wagon</td>
      <td>95.7</td>
      <td>169.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>62</td>
      <td>31</td>
      <td>6918.0</td>
    </tr>
    <tr>
      <th>55</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>165.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>69</td>
      <td>31</td>
      <td>6849.0</td>
    </tr>
    <tr>
      <th>38</th>
      <td>mazda</td>
      <td>hatchback</td>
      <td>93.1</td>
      <td>159.1</td>
      <td>ohc</td>
      <td>four</td>
      <td>68</td>
      <td>31</td>
      <td>6795.0</td>
    </tr>
    <tr>
      <th>30</th>
      <td>isuzu</td>
      <td>sedan</td>
      <td>94.3</td>
      <td>170.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>78</td>
      <td>24</td>
      <td>6785.0</td>
    </tr>
    <tr>
      <th>54</th>
      <td>nissan</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>165.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>69</td>
      <td>31</td>
      <td>6649.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>chevrolet</td>
      <td>sedan</td>
      <td>94.5</td>
      <td>158.8</td>
      <td>ohc</td>
      <td>four</td>
      <td>70</td>
      <td>38</td>
      <td>6575.0</td>
    </tr>
    <tr>
      <th>68</th>
      <td>toyota</td>
      <td>hatchback</td>
      <td>95.7</td>
      <td>158.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>62</td>
      <td>31</td>
      <td>6488.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>dodge</td>
      <td>hatchback</td>
      <td>93.7</td>
      <td>157.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>68</td>
      <td>31</td>
      <td>6377.0</td>
    </tr>
    <tr>
      <th>67</th>
      <td>toyota</td>
      <td>hatchback</td>
      <td>95.7</td>
      <td>158.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>62</td>
      <td>31</td>
      <td>6338.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>chevrolet</td>
      <td>hatchback</td>
      <td>94.5</td>
      <td>155.9</td>
      <td>ohc</td>
      <td>four</td>
      <td>70</td>
      <td>38</td>
      <td>6295.0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>dodge</td>
      <td>hatchback</td>
      <td>93.7</td>
      <td>157.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>68</td>
      <td>31</td>
      <td>6229.0</td>
    </tr>
    <tr>
      <th>50</th>
      <td>mitsubishi</td>
      <td>hatchback</td>
      <td>93.7</td>
      <td>157.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>68</td>
      <td>31</td>
      <td>6189.0</td>
    </tr>
    <tr>
      <th>37</th>
      <td>mazda</td>
      <td>hatchback</td>
      <td>93.1</td>
      <td>159.1</td>
      <td>ohc</td>
      <td>four</td>
      <td>68</td>
      <td>31</td>
      <td>6095.0</td>
    </tr>
    <tr>
      <th>49</th>
      <td>mitsubishi</td>
      <td>hatchback</td>
      <td>93.7</td>
      <td>157.3</td>
      <td>ohc</td>
      <td>four</td>
      <td>68</td>
      <td>37</td>
      <td>5389.0</td>
    </tr>
    <tr>
      <th>66</th>
      <td>toyota</td>
      <td>hatchback</td>
      <td>95.7</td>
      <td>158.7</td>
      <td>ohc</td>
      <td>four</td>
      <td>62</td>
      <td>35</td>
      <td>5348.0</td>
    </tr>
    <tr>
      <th>36</th>
      <td>mazda</td>
      <td>hatchback</td>
      <td>93.1</td>
      <td>159.1</td>
      <td>ohc</td>
      <td>four</td>
      <td>68</td>
      <td>30</td>
      <td>5195.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>chevrolet</td>
      <td>hatchback</td>
      <td>88.4</td>
      <td>141.1</td>
      <td>l</td>
      <td>three</td>
      <td>48</td>
      <td>47</td>
      <td>5151.0</td>
    </tr>
  </tbody>
</table>
</div>



### Question 9
### Concatenate two DataFrames and make a key for each DataFrame.

# SOLUTION

####  For this exercise, we're not provided with dataset or DataFrames to perform the concatenation operation.
#### And to make things happen, let's make use of the 2 newly created Dataframes in our previous answers.
#### I mean 'brands_expensive_df' and 'brand_mileage_avg' DataFrames.


```python
concat_df = pd.concat([brands_expensive_df, brand_mileage_avg_df], ignore_index = True, axis = 1).drop(2, axis = 1)
concat_df.columns = ["brands", "max_price", "avg_mileage"]
concat_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brands</th>
      <th>max_price</th>
      <th>avg_mileage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>alfa-romero</td>
      <td>16500.0</td>
      <td>20.333333</td>
    </tr>
    <tr>
      <th>1</th>
      <td>audi</td>
      <td>18920.0</td>
      <td>20.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bmw</td>
      <td>41315.0</td>
      <td>19.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>chevrolet</td>
      <td>6575.0</td>
      <td>41.000000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>dodge</td>
      <td>6377.0</td>
      <td>31.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>honda</td>
      <td>12945.0</td>
      <td>26.333333</td>
    </tr>
    <tr>
      <th>6</th>
      <td>isuzu</td>
      <td>15387.0</td>
      <td>31.000000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>jaguar</td>
      <td>36000.0</td>
      <td>14.333333</td>
    </tr>
    <tr>
      <th>8</th>
      <td>mazda</td>
      <td>18344.0</td>
      <td>28.000000</td>
    </tr>
    <tr>
      <th>9</th>
      <td>mercedes-benz</td>
      <td>45400.0</td>
      <td>18.000000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>mitsubishi</td>
      <td>8189.0</td>
      <td>29.500000</td>
    </tr>
    <tr>
      <th>11</th>
      <td>nissan</td>
      <td>13499.0</td>
      <td>31.400000</td>
    </tr>
    <tr>
      <th>12</th>
      <td>porsche</td>
      <td>37028.0</td>
      <td>17.000000</td>
    </tr>
    <tr>
      <th>13</th>
      <td>toyota</td>
      <td>15750.0</td>
      <td>28.714286</td>
    </tr>
    <tr>
      <th>14</th>
      <td>volkswagen</td>
      <td>9995.0</td>
      <td>31.750000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>volvo</td>
      <td>13415.0</td>
      <td>23.000000</td>
    </tr>
  </tbody>
</table>
</div>



### Question 10
### Merge two DataFrames using the following conditions.
#### Create two DataFrames using using two dicts (Dictionaries).
#### Merge two DataFrames and append second DataFrames as a new column to first Dataframe.

# SOLUTION

#### Same challenges like we had in question 9, there's no dataset for which to execute the task
#### Hence, we'll make use of the 2 DataFrames with which we executed Question 9.


```python
merge_df = brands_expensive_df.merge(brand_mileage_avg_df, how = "inner", on = "brand")
merge_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>brand</th>
      <th>max_price</th>
      <th>mileage_avg</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>alfa-romero</td>
      <td>16500.0</td>
      <td>20.333333</td>
    </tr>
    <tr>
      <th>1</th>
      <td>audi</td>
      <td>18920.0</td>
      <td>20.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bmw</td>
      <td>41315.0</td>
      <td>19.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>chevrolet</td>
      <td>6575.0</td>
      <td>41.000000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>dodge</td>
      <td>6377.0</td>
      <td>31.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>honda</td>
      <td>12945.0</td>
      <td>26.333333</td>
    </tr>
    <tr>
      <th>6</th>
      <td>isuzu</td>
      <td>15387.0</td>
      <td>31.000000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>jaguar</td>
      <td>36000.0</td>
      <td>14.333333</td>
    </tr>
    <tr>
      <th>8</th>
      <td>mazda</td>
      <td>18344.0</td>
      <td>28.000000</td>
    </tr>
    <tr>
      <th>9</th>
      <td>mercedes-benz</td>
      <td>45400.0</td>
      <td>18.000000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>mitsubishi</td>
      <td>8189.0</td>
      <td>29.500000</td>
    </tr>
    <tr>
      <th>11</th>
      <td>nissan</td>
      <td>13499.0</td>
      <td>31.400000</td>
    </tr>
    <tr>
      <th>12</th>
      <td>porsche</td>
      <td>37028.0</td>
      <td>17.000000</td>
    </tr>
    <tr>
      <th>13</th>
      <td>toyota</td>
      <td>15750.0</td>
      <td>28.714286</td>
    </tr>
    <tr>
      <th>14</th>
      <td>volkswagen</td>
      <td>9995.0</td>
      <td>31.750000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>volvo</td>
      <td>13415.0</td>
      <td>23.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
